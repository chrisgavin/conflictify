#!/usr/bin/env python3
for i in range(1, 101):
	if i % 3 == 0:
		print("bees", end="")
	if i % 5 == 0:
		print("beads", end="")
	if i % 3 != 0 and i % 5 != 0:
		print("%d" % i, end="")
	print("")
